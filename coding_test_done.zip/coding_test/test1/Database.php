<?php

//TODO: In real project this class should extend DatabaseInterface and extend some abstract class with default method realization
class Database
{

    private $_dbHost = '';
    private $_dbPort = 0;
    private $_dbUsername = '';
    private $_dbPassword = '';
    private $_dbName = '';
    private $_dbSocket = '';
    private $_dbLink = NULL;

    public function __construct($dbHost = '', $dbUsername = '', $dbPassword = '', $dbName = '', $dbPort = 3306, $dbSocket = '')
    {
        if (empty($dbHost) || empty($dbUsername) || empty($dbName))
        {
            throw new Exception('Not enough credentials for database connection in ' . __CLASS__);
        }
        $this->_dbHost = $dbHost;
        $this->_dbPort = $dbPort;
        $this->_dbUsername = $dbUsername;
        $this->_dbPassword = $dbPassword;
        $this->_dbName = $dbName;
        $this->_dbSocket = $dbSocket;
    }

    public function connect()
    {
        try
        {
            $this->_dbLink = new mysqli($this->_dbHost, $this->_dbUsername, $this->_dbPassword, $this->_dbName, $this->_dbPort, $this->_dbSocket);
        }
        catch (Exception $e)
        {
            throw new Exception('Can not connect to database in ' . __CLASS__.'. Error: '.$e->getMessage());

        }
    }

    public function fetchAll($sql)
    {
        if(empty($this->_dbLink))
            throw new Exception('Database link is down. Use connect method before queries.');

        $result = $this->_dbLink->query($sql);

        if(!$result)
            throw new Exception('Can not execute query "'.$sql.'". Error: '.$this->_dbLink->error);

        return $result;

    }
}