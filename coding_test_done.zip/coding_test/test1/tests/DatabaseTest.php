<?php
/**
 * The mock object with data should be used for testing database class but we have a test project
 */
include '../Database.php';

class DatabaseTest extends PHPUnit_Framework_TestCase
{

    private $_correctConnectData = array();
    private $_wrongConnectData = array();

    public function setUp()
    {
        parent::setUp();
        $this->_correctConnectData['dbHost'] = '127.0.0.1';
        $this->_correctConnectData['dbPort'] = 0;
        $this->_correctConnectData['dbUsername'] = 'root';
        $this->_correctConnectData['dbPassword'] = 'fuckoff';
        $this->_correctConnectData['dbName'] = 'test1';
        $this->_correctConnectData['dbSocket'] = '/var/run/mysqld/mysql.sock';

        $this->_wrongConnectData['dbHost'] = 'localhost';
        $this->_wrongConnectData['dbPort'] = 3306;
        $this->_wrongConnectData['dbUsername'] = 'root';
        $this->_wrongConnectData['dbPassword'] = 'nopass';
        $this->_wrongConnectData['dbName'] = 'test';
        $this->_wrongConnectData['dbSocket'] = '';
    }
    /**
     * @expectedException Exception
     * @expectedExceptionMessage Not enough credentials for database connection in
     */
    public function test__constructNoArguments()
    {
        $database = new Database();
    }

    public function test__constructCorrectArguments()
    {
        $database = new Database($this->_correctConnectData['dbHost'],$this->_correctConnectData['dbUsername'],$this->_correctConnectData['dbPassword'],$this->_correctConnectData['dbPassword'],$this->_correctConnectData['dbPort'],$this->_correctConnectData['dbSocket']);

        $this->assertInstanceOf(Database::class, $database);
    }
    /**
     * @expectedException Exception
     * @expectedExceptionMessage Can not connect to database in
     */
    public function testConnectWrongArguments()
    {
        $database = new Database($this->_wrongConnectData['dbHost'],$this->_wrongConnectData['dbUsername'],$this->_wrongConnectData['dbPassword'],$this->_wrongConnectData['dbName'],$this->_wrongConnectData['dbPort']);
        $database->connect();
    }
    public function testConnectCorrectArguments()
    {
        $database = new Database($this->_correctConnectData['dbHost'],$this->_correctConnectData['dbUsername'],$this->_correctConnectData['dbPassword'],$this->_correctConnectData['dbName'],$this->_correctConnectData['dbPort'], $this->_correctConnectData['dbSocket']);
        $database->connect();
        $this->assertInstanceOf(Database::class, $database);
    }

    public function testFetchAllCorrect()
    {
        $database = new Database($this->_correctConnectData['dbHost'],$this->_correctConnectData['dbUsername'],$this->_correctConnectData['dbPassword'],$this->_correctConnectData['dbName'],$this->_correctConnectData['dbPort'], $this->_correctConnectData['dbSocket']);
        $database->connect();
        $sql = 'SELECT * FROM `tree_menu` ORDER BY `node_id` LIMIT 1';
        $data = $database->fetchAll($sql);
        $this->assertInstanceOf(mysqli_result::class, $data);
    }
}
