Iris media code challenge

There are two tests in folders test1 and test2.
In each folder there is a text file containing test details please read them carefully.

Please put all your files for each test in its folder and send it back to max@irismediainc.com

Good luck!
