<?php

require_once dirname(__FILE__).'/abstractTree.class.php';

class myTree extends abstractTree
{
    /*
     * $db db_object databaselink
     */
    private $_db = NULL;
    
    
    public function __construct(Database $db)
    {
        $this->_db = $db;
    }

    /**
     * @return array
     * @throws Exception
     */
    public function showPreloadedTree()
	{
        //TODO: this method depends on mysql database. Between this class and database class should be model class which prepares data from mysql_result to array
        $result = array();
        $data = $this->_db->fetchAll('SELECT * FROM `tree_menu` ORDER BY `Name` ASC');
        while($row = $data->fetch_assoc())
        {
            $result[$row['parent_id']][] = array('node_id' => $row['node_id'], 'name' => $row['Name']);
        }

        return $result;
	}

    /**
     * @return array
     * @throws Exception
     */
	public function ajaxShowTree()
	{
        //TODO: this method depends on mysql database. Between this class and database class should be model class which prepares data from mysql_result to array
        $result = array();
        $data = $this->_db->fetchAll('SELECT * FROM `tree_menu` WHERE `parent_id` = 0 ORDER BY `Name` ASC');
        while($row = $data->fetch_assoc())
        {
            $result[$row['parent_id']][] = array('node_id' => $row['node_id'], 'name' => $row['Name']);
        }

        return $result;
	}

    /**
     * @param $nodeId
     * @return array
     * @throws Exception
     */
	public function ajaxFetchTreeNode($nodeId)
	{
        if(!is_integer($nodeId))
            $nodeId = intval($nodeId);
        $result = array();

        //TODO: this method depends on mysql database. Between this class and database class should be model class which prepares data from mysql_result to array
        $data = $this->_db->fetchAll('SELECT * FROM `tree_menu` WHERE `parent_id` = '.$nodeId);
        while($row = $data->fetch_assoc())
        {
            $result[] = array('node_id' => $row['node_id'], 'name' => $row['Name']);
        }

        return $result;
	}
}