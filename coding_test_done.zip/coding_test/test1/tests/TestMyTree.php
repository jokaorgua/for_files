<?php

include '../myTree.class.php';

class TestMyTree extends PHPUnit_Framework_TestCase
{

    /**
     * @expectedException        Exception
     * @expectedExceptionMessage Database link is not a resource in myTree
     */
    public function test__construct()
    {
        $db = NULL;
        $mytreeObject = new myTree($db);

    }
    
    //TODO: a lot of tests for every method that compare data in database and etalon arrays (maybe it is better to use mock object)
}
