<?php

require_once dirname(__FILE__) . '/myTree.class.php';
require_once dirname(__FILE__) . '/Database.php';

$dbHost = '127.0.0.1';
$dbPort = 0;
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'test1';
$dbSocket = '/var/run/mysqld/mysql.sock';

$database = new Database($dbHost, $dbUsername, $dbPassword, $dbName, $dbPort, $dbSocket);
$database->connect();
$tree = new myTree($database);

if (!empty($_GET['mode']) && $_GET['mode'] == 'ajax' && !empty($_GET['method']) && $_GET['method'] == 'getnodedata' && !empty($_GET['node_id']))
{
    $nodeId = intval($_GET['node_id']);
    $preloadedTreeData = $tree->ajaxFetchTreeNode($nodeId);
    echo json_encode($preloadedTreeData);
}
elseif (!empty($_GET['mode']) && $_GET['mode'] == 'ajax')
{
    $preloadedTreeData = $tree->ajaxShowTree();
    $preloadedTreeData = json_encode($preloadedTreeData);
    include './templates/indexajax.html';
}
else
{
    $preloadedTreeData = $tree->showPreloadedTree();
    $preloadedTreeData = json_encode($preloadedTreeData);
    include './templates/index.html';
}


