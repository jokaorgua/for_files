1. run composer install
2. wait
3. run the index.php